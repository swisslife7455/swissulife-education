(function () {
  "use strict";
  var S = window.SETTINGS || {};
  var BASE = (function () { var sc = document.currentScript; return sc && sc.src ? sc.src.replace(/app\.js(\?.*)?$/, "") : ""; })();
  function asset(p) { return !p || /^(https?:|data:|\/)/.test(p) ? p : BASE + p; }
  var root = document.documentElement;
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  /* ---------- language ---------- */
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  $$("option[data-ar]").forEach(function (o) { o.setAttribute("data-en", o.textContent); });
  function setLang(lang) {
    var ar = lang === "ar";
    root.lang = ar ? "ar" : "en";
    root.dir = ar ? "rtl" : "ltr";
    root.classList.toggle("ar", ar);
    root.classList.toggle("en", !ar);
    $$("option[data-ar]").forEach(function (o) { o.textContent = ar ? o.getAttribute("data-ar") : o.getAttribute("data-en"); });
    store("se-lang", lang);
    renderSettings(); renderCheck(); renderMsg(); renderTrust(); renderGoogle(); fillPass(false);
  }
  function lang() { return root.classList.contains("ar") ? "ar" : "en"; }
  $("#langBtn").addEventListener("click", function (e) {
    e.preventDefault();
    var next = lang() === "ar" ? "en" : "ar", alt = root.getAttribute("data-alt");
    if (alt) { store("se-lang", next); location.href = alt + (location.hash || ""); return; }  // separate English and Arabic pages (SEO)
    setLang(next);
  });

  /* ---------- menu ---------- */
  var nav = $("#nav"), menuBtn = $("#menuBtn");
  menuBtn.addEventListener("click", function () {
    var open = nav.classList.toggle("open");
    menuBtn.setAttribute("aria-expanded", open ? "true" : "false");
  });

  /* ---------- routing ---------- */
  var views = $$("[data-view]");
  var names = views.map(function (v) { return v.getAttribute("data-view"); });
  function route() {
    var id = (location.hash || "").slice(1);
    var view = names.indexOf(id) > -1 ? id : null, target = null;
    if (!view) {
      target = id ? document.getElementById(id) : null;
      var host = target && target.closest("[data-view]");
      view = host ? host.getAttribute("data-view") : names[0];
    }
    views.forEach(function (v) { v.classList.toggle("view-hidden", v.getAttribute("data-view") !== view); });
    $$(".nav a[href^='#']").forEach(function (a) {
      var h = a.getAttribute("href").slice(1);
      if (h === view || h === id) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
    });
    nav.classList.remove("open"); menuBtn.setAttribute("aria-expanded", "false");
    if (target) { setTimeout(function () { target.scrollIntoView({ block: "start" }); }, 0); }
    else { window.scrollTo(0, 0); }
  }
  window.addEventListener("hashchange", route);
  document.addEventListener("click", function (e) {
    var a = e.target.closest("a[data-pkg]");
    if (a) { var sel = $("#bPkg"); if (sel) { sel.value = a.getAttribute("data-pkg"); renderMsg(); } }
  });

  /* ---------- settings ---------- */
  function waUrl(text) { return "https://wa.me/" + S.whatsapp + "?text=" + encodeURIComponent(text); }
  function pretty(n) { return "+" + n.replace(/^(\d{3})(\d{2})(\d{3})(\d+)$/, "$1 $2 $3 $4"); }
  function setText(sel, txt) { var el = $(sel); if (el) el.textContent = txt; return el; }
  function telHref(n) { return "tel:" + String(n).replace(/[^\d+]/g, ""); }
  function renderSettings() {
    var ar = lang() === "ar", L = ar ? 1 : 0;
    var hasWa = /^\d{8,15}$/.test(S.whatsapp || "");
    var greet = ar ? "مرحباً، أودّ معرفة المزيد عن سويسولايف للتعليم." : "Hello, I would like to know more about Swissulife Education.";
    // WhatsApp: shown only when a number is set
    var wp = $("#waPanel"); if (wp) wp.hidden = !hasWa;
    setText("#waText", hasWa ? pretty(S.whatsapp) : "");
    var wb = $("#waBtn"); if (wb && hasWa) { wb.href = waUrl(greet); wb.target = "_blank"; wb.rel = "noopener"; }
    var wf = $("#waFloat"); if (wf) { wf.hidden = !hasWa; if (hasWa) { wf.href = waUrl(greet); wf.target = "_blank"; wf.rel = "noopener"; } }
    // offices
    var offices = (S.offices || []).filter(function (o) { return (o.address && o.address[0]) || o.phone; });
    var list = $("#officeList");
    if (list) {
      list.innerHTML = offices.map(function (o) {
        return '<div class="panel"><span class="lbl-mono">' + esc(o.city[L]) + '</span><b>' + esc((o.address && (o.address[L] || o.address[0])) || (ar ? "بالهاتف وواتساب" : "By phone and WhatsApp")) + '</b>' +
          (o.phone ? '<span class="hint" dir="ltr">' + esc(o.phone) + '</span>' : '') +
          '<div class="btn-row">' + (o.phone ? '<a class="btn solid" href="' + telHref(o.phone) + '">' + (ar ? "اتصل بنا" : "Call") + '</a>' : '') +
          (o.maps ? '<a class="btn ghost" href="' + esc(o.maps) + '" target="_blank" rel="noopener">' + (ar ? "الخريطة" : "Map") + '</a>' : '') + '</div></div>';
      }).join("");
    }
    var hours = S.hours && S.hours[ar ? "ar" : "en"];
    setText("#hoursText", hours || "");
    var em = $("#emailPanel"); if (em) em.hidden = !S.email; setText("#emailText", S.email || "");
    $$(".li-link").forEach(function (a) { var u = S.linkedin || (a.classList.contains("li-foot") ? S.linkedinCompany : ""); if (u) { a.href = u; a.hidden = false; } else { a.hidden = true; } });
    $$(".li-row").forEach(function (r) { r.hidden = !S.linkedin; });
    $$(".ig-foot").forEach(function (a) { a.href = "https://www.instagram.com/" + (S.instagram || "") + "/"; });
    var ig = $("#igLink"); if (ig) { ig.textContent = "@" + (S.instagram || ""); ig.href = "https://www.instagram.com/" + (S.instagram || "") + "/"; }
    // licence: shown only when set
    var lic = S.licence ? (ar ? "مكتب خدمات تعليمية مرخّص، رقم الترخيص " : "Licensed educational services office, licence no. ") + S.licence : "";
    var lt = setText("#licenceText", lic); if (lt) lt.hidden = !lic;
    setText("#licFoot", lic ? " · " + lic : "");
    $$(".lic-item").forEach(function (el) {
      el.innerHTML = S.licence ? "<b>" + (ar ? "مكتب مرخّص" : "Licensed office") + "</b> " + esc(S.licence) : "<b>" + (ar ? "مكاتب في دبي وجنيف" : "Offices in Dubai and Geneva") + "</b>";
    });
    // booking: WhatsApp if set, otherwise call the first office with a phone
    var phoneOffice = offices.filter(function (o) { return o.phone; })[0];
    var miss = $("#waMissing"); if (miss) miss.hidden = hasWa;
    var send = $("#bSend"); if (send) send.hidden = !hasWa;
    var call = $("#bCall");
    if (call) { call.hidden = hasWa || !phoneOffice; if (phoneOffice) { call.href = telHref(phoneOffice.phone); setText("#bCallTxt", (ar ? "اتصل بمكتب " : "Call our ") + phoneOffice.city[L] + (ar ? "" : " office") + " · " + phoneOffice.phone); } }
    // founder note
    $$(".founder-note").forEach(function (el) {
      var t = S.founderNote && S.founderNote[el.getAttribute("data-lang")];
      el.textContent = t || ""; el.hidden = !t;
    });
  }

  /* ---------- trust: founder photo, proof, stories ---------- */
  var PH_EN = '<div class="ph"><svg viewBox="0 0 72 72" aria-hidden="true"><circle cx="36" cy="26" r="14" fill="none" stroke="currentColor" stroke-width="2"/><path d="M10 66c3-14 13-22 26-22s23 8 26 22" fill="none" stroke="currentColor" stroke-width="2"/></svg>[FOUNDER PHOTO]</div>';
  function renderTrust() {
    var ar = lang() === "ar";
    $$(".founder-photo").forEach(function (box) {
      if (S.founderPhoto) {
        if (!box.querySelector("img")) { var im = new Image(); im.src = asset(S.founderPhoto); im.alt = "Bakri Bassam Jarkji"; im.loading = "lazy"; box.innerHTML = ""; box.appendChild(im); }
      } else { box.innerHTML = PH_EN; }
    });
    $$(".founder-avatar").forEach(function (el) {
      if ((S.founderAvatar || S.founderPhoto) && !el.querySelector("img")) { var im = new Image(); im.src = asset(S.founderAvatar || S.founderPhoto); im.alt = ""; el.textContent = ""; el.appendChild(im); }
    });
    var lic = "";
    var al = $("#aboutLicence"); if (al) { al.textContent = S.licence ? (ar ? "مكتب خدمات تعليمية مرخّص · رقم الترخيص " : "Licensed educational services office · licence no. ") + S.licence : ""; al.hidden = !S.licence; }
    var P = S.proof || {}, row = $("#proofRow"), items = [];
    if (P.students) items.push([P.students, ar ? "طالباً ساعدناهم" : "students advised"]);
    if (P.universities) items.push([P.universities, ar ? "جامعة قُبلوا فيها" : "universities they joined"]);
    if (P.years) items.push([P.years, ar ? "سنوات خبرة" : "years placing students"]);
    if (P.instagram) items.push([P.instagram, ar ? "متابع على إنستغرام" : "followers on Instagram"]);
    if (row) { row.innerHTML = items.map(function (i) { return "<li><b>" + esc(i[0]) + "</b><span>" + esc(i[1]) + "</span></li>"; }).join(""); row.hidden = !items.length; }
    var T2 = S.testimonials || [], sec = $("#stories"), list = $("#storyList");
    if (sec && list) {
      list.innerHTML = T2.map(function (t) {
        return '<figure class="story-card"><blockquote>' + esc(ar ? (t.ar || t.en) : (t.en || t.ar)) + '</blockquote><figcaption>' + esc(t.name || "") + (t.detail ? " · " + esc(t.detail) : "") + '</figcaption></figure>';
      }).join("");
      sec.hidden = !T2.length;
    }
  }

  /* ---------- rotating boarding pass ---------- */
  var R = (S.routes || []).slice(), ri = 0, rTimer = null, rPaused = false;
  var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  function routeAt(i) {
    if (i < R.length) return R[i];
    return { you: true, from: "DXB", fromCity: ["Dubai", "دبي"], to: "?", toCity: ["Your destination", "وجهتك"], major: ["Your major", "تخصصك"], intake: ["2027", "٢٠٢٧"] };
  }
  function total() { return R.length + 1; }
  function fillPass(animate) {
    var pass = $("#pass"); if (!pass) return;
    var a = lang() === "ar" ? 1 : 0, r = routeAt(ri);
    function put() {
      $("#pFrom").textContent = r.from; $("#pFromCity").textContent = r.fromCity[a];
      $("#pTo").textContent = r.to; $("#pToCity").textContent = r.toCity[a];
      $("#pTo").classList.toggle("q", !!r.you);
      $("#pMajor").textContent = r.major[a]; $("#pIntake").textContent = r.intake[a];
      $("#pName").textContent = r.name ? r.name[a] : (a ? "أنت" : "You");
      $("#pNum").textContent = String(ri + 1).padStart(2, "0") + " / " + String(total()).padStart(2, "0");
      $("#pCta").hidden = !r.you;
      var real = R.some(function (x) { return x.student; });
      $("#pLabel").textContent = r.you ? (a ? "مسارك القادم" : "Your route next")
        : (r.student ? (r.source === "google" ? (a ? "مسار حقيقي · من تقييماتنا على Google" : "A real route · from our Google reviews") : (a ? "مسار حقيقي لطالب من سويسولايف" : "A real route from a Swissulife student"))
        : (r.name ? (a ? "أمثلة توضيحية · الأسماء للتوضيح فقط" : "Example passes · names are illustrative") : (a ? "مسارات نخطط لها · أمثلة" : "Routes we plan · examples")));
      pass.setAttribute("aria-label", (a ? "بطاقة صعود: " : "Boarding pass: ") + r.fromCity[a] + " → " + r.toCity[a] + ", " + r.major[a]);
      var line = $("#pLine"); if (line) { line.style.animation = "none"; void line.getBBox(); line.style.animation = ""; }
    }
    if (animate && !reduceMotion) { pass.classList.add("printing"); setTimeout(function () { put(); pass.classList.remove("printing"); }, 350); }
    else put();
  }
  function go(step) { ri = (ri + step + total()) % total(); fillPass(true); }
  function startRotate() {
    clearInterval(rTimer);
    if (reduceMotion || rPaused) return;
    rTimer = setInterval(function () { if (!document.hidden) go(1); }, 7000);
  }
  function setPaused(p) {
    rPaused = p;
    var ico = $("#pPauseIco"), btn = $("#pPause");
    if (ico) ico.innerHTML = p ? '<path d="M8 5v14l11-7z"/>' : '<path d="M8 5v14M16 5v14"/>';
    if (btn) btn.setAttribute("aria-label", p ? "Play" : "Pause");
    startRotate();
  }
  if ($("#pass")) {
    $("#pNext").addEventListener("click", function () { go(1); startRotate(); });
    $("#pPrev").addEventListener("click", function () { go(-1); startRotate(); });
    $("#pPause").addEventListener("click", function () { setPaused(!rPaused); });
    var hov = $(".pass-wrap");
    hov.addEventListener("mouseenter", function () { clearInterval(rTimer); });
    hov.addEventListener("mouseleave", startRotate);
    if (reduceMotion) setPaused(true);
  }

  /* ---------- welcome video ---------- */
  var V = S.welcomeVideo || {};
  function hideKey() { return "se-welcome-hidden"; }
  function setupWelcome() {
    if (!V.src) return;
    var box = $("#welcome"), prev = $("#wPreview"), modal = $("#wModal"), player = $("#wPlayer");
    var hiddenAt = Number(store(hideKey()) || 0);
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (V.poster) { prev.poster = asset(V.poster); player.poster = asset(V.poster); }
    prev.src = asset(V.preview || V.src);
    if (!reduce) { prev.autoplay = true; var pp = prev.play(); if (pp && pp.catch) pp.catch(function () {}); }
    if (!hiddenAt || Date.now() - hiddenAt > 7 * 864e5) { setTimeout(function () { box.hidden = false; }, 6000); }
    $$("[data-watch]").forEach(function (b) { b.hidden = false; b.addEventListener("click", open); });
    function open() {
      player.src = asset(V.src);
      $$("track", player).forEach(function (t) { t.remove(); });
      ["en", "ar"].forEach(function (l) {
        if (V.captions && V.captions[l]) { var t = document.createElement("track"); t.kind = "subtitles"; t.srclang = l; t.label = l === "ar" ? "العربية" : "English"; t.src = asset(V.captions[l]); if (l === lang()) t.default = true; player.appendChild(t); }
      });
      if (modal.showModal) modal.showModal(); else modal.setAttribute("open", "");
      prev.pause();
      if (window.gtag) window.gtag("event", "welcome_video_play");
      var p = player.play(); if (p && p.catch) p.catch(function () {});
    }
    function close() { player.pause(); if (modal.close) modal.close(); else modal.removeAttribute("open"); if (!reduce && !box.hidden) { var p = prev.play(); if (p && p.catch) p.catch(function () {}); } }
    $("#wOpen").addEventListener("click", open);
    $("#wClose").addEventListener("click", close);
    $("#wBook").addEventListener("click", close);
    modal.addEventListener("click", function (e) { if (e.target === modal) close(); });
    modal.addEventListener("close", function () { player.pause(); });
    $("#wHide").addEventListener("click", function () { box.hidden = true; prev.pause(); store(hideKey(), String(Date.now())); });
  }

  /* ---------- Google reviews ---------- */
  var G = S.google || {}, gLoaded = false;
  function renderGoogle() {
    var ar = lang() === "ar";
    if (!G.placeId) { $$(".g-chip,.g-item,#reviews").forEach(function (el) { el.hidden = true; }); return; }
    var read = "https://www.google.com/maps/place/?q=place_id:" + G.placeId;
    var write = "https://search.google.com/local/writereview?placeid=" + G.placeId;
    $$(".g-read").forEach(function (a) { a.href = read; });
    $$(".g-write").forEach(function (a) { a.href = write; });
    if (G.rating) $$(".g-rating").forEach(function (el) { el.textContent = G.rating; });
    if (G.count) $$(".g-count").forEach(function (el) { el.textContent = String(G.count); });
    var asof = G.asOf && (ar ? G.asOf.ar : G.asOf.en);
    $$(".g-asof").forEach(function (el) { el.textContent = asof ? (ar ? "حتى " : "As of ") + asof + "." : ""; });
    if (G.mapsKey && !gLoaded) { gLoaded = true; loadLive(); }
  }
  function loadLive() {
    window.__seGmaps = function () {
      google.maps.importLibrary("places").then(function (lib) {
        var place = new lib.Place({ id: G.placeId, requestedLanguage: lang() });
        return place.fetchFields({ fields: ["rating", "userRatingCount", "reviews"] }).then(function () { return place; });
      }).then(function (place) {
        if (place.rating) { G.rating = place.rating.toFixed(1); }
        if (place.userRatingCount) { G.count = place.userRatingCount; G.asOf = null; }
        var list = (place.reviews || []).filter(function (r) { return r.text; });
        $("#gGrid").innerHTML = list.slice(0, 4).map(function (r) {
          var a = r.authorAttribution || {};
          return '<figure class="g-card"><span class="stars" aria-label="' + r.rating + ' stars">' + new Array((r.rating || 5) + 1).join('<svg viewBox="0 0 20 20"><path d="M10 1.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9L10 14.9l-5.2 2.8 1-5.9L1.5 7.7l5.9-.8z"/></svg>') + '</span>' +
            '<blockquote>' + esc(r.text) + '</blockquote><figcaption>' + (a.photoURI ? '<img src="' + esc(a.photoURI) + '" alt="" referrerpolicy="no-referrer">' : '') +
            '<span><a href="' + esc(a.uri || "#") + '" target="_blank" rel="noopener">' + esc(a.displayName || "Google user") + '</a><br><time>' + esc(r.relativePublishTimeDescription || "") + '</time></span></figcaption></figure>';
        }).join("");
        $("#gLive").hidden = !list.length;
        renderGoogle();
      }).catch(function () { /* keep the static badge */ });
    };
    var s = document.createElement("script");
    s.src = "https://maps.googleapis.com/maps/api/js?key=" + encodeURIComponent(G.mapsKey) + "&v=weekly&loading=async&callback=__seGmaps";
    s.async = true; s.onerror = function () {}; document.head.appendChild(s);
  }

  /* ---------- recognition checker ---------- */
  var T = {
    nat: {
      uae: {
        en: ["The UAE rule for Emirati students", "Emirati students, self-funded or sponsored, should choose a university ranked in the top 50 in the world for their field, using rankings the Ministry of Higher Education and Scientific Research approves. Outside these standards, the degree may not be recognised for jobs, promotions and further study at home.", "Check with the ministry before enrolling. Exemption requests go through the ministry's own website only. Avoid distance or online programmes unless the ministry has approved them."],
        ar: ["قاعدة الطلاب الإماراتيين", "الطالب الإماراتي، سواء على حسابه أو مبتعث، يجب أن يختار جامعة من أفضل ٥٠ جامعة في العالم في تخصصه، حسب التصنيفات المعتمدة من وزارة التعليم العالي والبحث العلمي. وإذا لم يلتزم بهذه المعايير، فقد لا تُعتمد الشهادة للوظيفة أو الترقية أو الدراسات العليا في الدولة.", "راجعوا الوزارة قبل التسجيل، وطلبات الاستثناء تكون عبر موقع الوزارة الرسمي فقط. وتجنّبوا برامج التعليم عن بُعد إلا إذا كانت معتمدة من الوزارة."]
      },
      ksa: {
        en: ["The Saudi rule", "Saudi students should study at universities and programmes recognised by the Ministry of Education. Verify both the university and the programme with the ministry before registering.", "Sponsored students follow their sponsor's approved list of institutions. Self-funded students should check recognition themselves, or with us, before applying."],
        ar: ["قاعدة الطلاب السعوديين", "يجب أن يدرس الطالب السعودي في جامعة وبرنامج معترف بهما من وزارة التعليم. تأكدوا من الجامعة والبرنامج مع الوزارة قبل التسجيل.", "الطالب المبتعث يلتزم بقائمة الجهة المبتعثة. أما الطالب على حسابه الخاص فعليه التحقق من الاعتراف بنفسه، أو معنا، قبل التقديم."]
      },
      gcc: {
        en: ["Other GCC nationals", "Each GCC country has its own authority for recognising degrees from abroad, and some publish lists of approved universities.", "Check with your country's ministry of higher education before applying. We confirm the current rule with you in the Pathway Plan."],
        ar: ["مواطنو دول الخليج الأخرى", "لكل دولة خليجية جهة خاصة للاعتراف بالشهادات من الخارج، وبعضها ينشر قوائم بالجامعات المعتمدة.", "راجعوا وزارة التعليم العالي في بلدكم قبل التقديم، ونتأكد معكم من القاعدة الحالية في خطة المسار."]
      },
      res: {
        en: ["UAE residents", "To use a degree from abroad in the UAE, you will need recognition (equivalency) from the Ministry of Higher Education and Scientific Research after graduation. Many private-sector jobs accept a recognised degree; government roles and licensed professions ask for the ministry's recognition.", "Also check the rules of your home country if the student may work there."],
        ar: ["المقيمون في الإمارات", "لاستخدام شهادة من الخارج في الإمارات، تحتاج إلى معادلة من وزارة التعليم العالي والبحث العلمي بعد التخرج. كثير من وظائف القطاع الخاص تقبل الشهادة المعترف بها، أما الوظائف الحكومية والمهن المرخّصة فتطلب اعتراف الوزارة.", "وتأكدوا أيضاً من قواعد بلدكم الأصلي إذا كان الطالب قد يعمل هناك."]
      }
    },
    field: {
      medicine: { en: "Medicine and health are licensed professions. Licensing at home depends on recognition, and some countries keep their own list of accepted medical schools. Plan for this from day one.", ar: "الطب والعلوم الصحية مهن مرخّصة، والترخيص في بلدكم يعتمد على الاعتراف، وبعض الدول لها قائمة خاصة بكليات الطب المقبولة. خططوا لذلك من اليوم الأول." },
      engineering: { en: "Engineering is a licensed profession. In the UAE, the Society of Engineers asks for the ministry's recognition of the degree before membership.", ar: "الهندسة مهنة مرخّصة. في الإمارات، جمعية المهندسين تطلب اعتراف الوزارة بالشهادة قبل العضوية." },
      law: { en: "Law usually needs a local qualification or a conversion step before practising at home. Ask us early so the route fits.", ar: "يحتاج القانون غالباً إلى مؤهل محلي أو خطوة معادلة قبل الممارسة في بلدكم. اسألونا مبكراً ليكون المسار مناسباً." },
      other: { en: "In this field, the ranking of the specific programme matters most. We check it for each university on your shortlist.", ar: "في هذا التخصص، تصنيف البرنامج نفسه هو الأهم، ونتحقق منه لكل جامعة في قائمتكم." }
    },
    dest: {
      ch: { en: "Switzerland: many public bachelor's programmes teach in German, French or Italian, while private hospitality and business schools often teach in English. Check the school is accredited in Switzerland and the field ranking.", ar: "سويسرا: كثير من برامج البكالوريوس الحكومية تدرّس بالألمانية أو الفرنسية أو الإيطالية، بينما تدرّس مدارس الضيافة والأعمال الخاصة غالباً بالإنجليزية. تأكدوا من أن المدرسة معتمدة في سويسرا ومن تصنيف التخصص." },
      eu: { en: "Europe: check the programme is officially accredited in its country, the teaching language, and any entry tests.", ar: "أوروبا: تأكدوا من أن البرنامج معتمد رسمياً في بلده، ومن لغة الدراسة، وأي اختبارات قبول." },
      uk: { en: "UK and Ireland: undergraduate applications go through UCAS (UK) or the CAO (Ireland), with fixed deadlines. Check the course ranking for your field.", ar: "بريطانيا وأيرلندا: التقديم للبكالوريوس عبر UCAS في بريطانيا أو CAO في أيرلندا، بمواعيد ثابتة. تأكدوا من تصنيف التخصص." },
      na: { en: "US, Canada, Australia: check the university's accreditation and the field ranking. Applications run on early and regular rounds.", ar: "أمريكا وكندا وأستراليا: تأكدوا من اعتماد الجامعة وتصنيف التخصص. التقديم على مراحل مبكرة وعادية." }
    }
  };
  function radio(name) { var r = $("input[name='" + name + "']:checked"); return r ? r.value : ""; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function renderCheck() {
    var box = $("#checkResult"); if (!box) return;
    var L = lang(), nat = T.nat[radio("nat")] || T.nat.uae, f = $("#field").value, d = T.dest[radio("dest")] || T.dest.ch;
    var fieldNote = (T.field[f] || T.field.other)[L], n = nat[L];
    var lbl = L === "ar"
      ? { rule: "القاعدة", field: "التخصص", dest: "الوجهة", next: "الخطوة التالية", nextTxt: "في خطة المسار نطبّق هذه القواعد على كل جامعة في قائمتكم ونسلّمكم التحقق مكتوباً.", btn: "احجز خطة المسار", fine: "معلومات عامة وليست قراراً رسمياً. القواعد تتغير، ونتأكد من القواعد الحالية للوزارة في خطة المسار.", src: "وزارة التعليم العالي والبحث العلمي (الإمارات)" }
      : { rule: "The rule", field: "Your field", dest: "Your destination", next: "Next step", nextTxt: "In the Pathway Plan we apply these rules to every university on your shortlist and give you the check in writing.", btn: "Book a Pathway Plan", fine: "General information, not an official ruling. Rules change; we confirm the ministry's current rules during your Pathway Plan.", src: "UAE Ministry of Higher Education and Scientific Research" };
    box.innerHTML =
      '<h3>' + esc(n[0]) + '</h3>' +
      '<div class="rule"><b>' + lbl.rule + '</b><p>' + esc(n[1]) + '</p><p>' + esc(n[2]) + '</p></div>' +
      '<div class="rule"><b>' + lbl.field + '</b><p>' + esc(fieldNote) + '</p></div>' +
      '<div class="rule"><b>' + lbl.dest + '</b><p>' + esc(d[L]) + '</p></div>' +
      '<div class="rule"><b>' + lbl.next + '</b><p>' + lbl.nextTxt + '</p></div>' +
      '<div class="btn-row"><a class="btn primary" href="book.html">' + lbl.btn + '</a></div>' +
      '<p class="fine">' + lbl.fine + ' <a href="https://www.mohesr.gov.ae/" target="_blank" rel="noopener">' + lbl.src + '</a></p>';
  }
  var cf = $("#checkForm");
  if (cf) { cf.addEventListener("change", function () { renderCheck(); syncBookFromCheck(); }); cf.addEventListener("submit", function (e) { e.preventDefault(); }); }
  function syncBookFromCheck() {
    var map = { ch: "Switzerland", eu: "Europe", uk: "UK / Ireland", na: "US / Canada / Australia" };
    var sel = $("#bDest"); if (sel) { sel.value = map[radio("dest")] || sel.value; renderMsg(); }
  }

  /* ---------- booking request: emailed to the team, WhatsApp as a second channel ---------- */
  function optText(id) { var s = $(id); return s && s.options[s.selectedIndex] ? s.options[s.selectedIndex].textContent : ""; }
  function val(id) { var el = $(id); return el ? (el.value || "").trim() : ""; }
  var bookRef = "";
  function newRef() {
    var d = new Date(), p = function (n) { return (n < 10 ? "0" : "") + n; };
    return "SE-" + p(d.getMonth() + 1) + p(d.getDate()) + "-" + Math.random().toString(36).slice(2, 6).toUpperCase();
  }
  function buildMsg() {
    var ar = lang() === "ar", name = val("#bName"), note = val("#bNote"), phone = val("#bPhone"), email = val("#bEmail");
    var lines = ar
      ? ["مرحباً سويسولايف للتعليم،", "أودّ حجز " + optText("#bPkg") + ".", "", "الاسم: " + (name || "—"), "الجوال: " + (phone || "—"), "أنا: " + optText("#bRole"), "الطالب في: " + optText("#bLevel"), "الوجهة: " + optText("#bDest"), "الوقت المناسب: " + optText("#bWhen")]
      : ["Hello Swissulife Education,", "I would like to book: " + optText("#bPkg") + ".", "", "Name: " + (name || "—"), "Mobile: " + (phone || "—"), "I am: " + optText("#bRole"), "Student is in: " + optText("#bLevel"), "Interested in: " + optText("#bDest"), "Best time: " + optText("#bWhen")];
    if (email) lines.push((ar ? "البريد: " : "Email: ") + email);
    if (note) lines.push((ar ? "ملاحظة: " : "Note: ") + note);
    if (bookRef) lines.push((ar ? "رقم الطلب: " : "Ref: ") + bookRef);
    return lines.join("\n");
  }
  function hasWa() { return /^\d{8,15}$/.test(S.whatsapp || ""); }
  function renderMsg() {
    var p = $("#msgPreview"); if (p) p.textContent = buildMsg();
    ["#bSend", "#bDoneWa"].forEach(function (id) { var a = $(id); if (a) { a.hidden = !hasWa(); if (hasWa()) a.href = waUrl(buildMsg()); } });
  }
  var bf = $("#bookForm");
  if (bf) {
    bf.addEventListener("input", renderMsg);
    bf.addEventListener("change", renderMsg);
    bf.addEventListener("submit", function (e) {
      e.preventDefault();
      var ar = lang() === "ar", state = $("#copyState"), btn = $("#bSubmit");
      if (!val("#bName")) { $("#bName").focus(); state.textContent = ar ? "اكتبوا الاسم أولاً." : "Add your name first."; return; }
      if (!/^[+0-9 ()-]{7,20}$/.test(val("#bPhone"))) { $("#bPhone").focus(); state.textContent = ar ? "اكتبوا رقم جوال صحيحاً." : "Add a valid mobile number."; return; }
      var em = val("#bEmail"); if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) { $("#bEmail").focus(); state.textContent = ar ? "اكتبوا بريداً إلكترونياً صحيحاً." : "Add a valid email address."; return; }
      if (val("#bHoney")) return;
      bookRef = newRef(); renderMsg();
      var data = {
        _subject: "New booking request " + bookRef + ": " + optText("#bPkg") + " · " + val("#bName"),
        Ref: bookRef,
        _template: "table", _captcha: "false",
        Name: val("#bName"), Mobile: val("#bPhone"), Email: em || "-",
        "Booking for": optText("#bPkg"), "They are": optText("#bRole"), "Student is in": optText("#bLevel"),
        "Interested in": optText("#bDest"), "Best time": optText("#bWhen"), Note: val("#bNote") || "-",
        Language: ar ? "Arabic" : "English", Page: location.href
      };
      if (em) data._replyto = em;
      var to = S.bookingEmail || S.email;
      function done() {
        bf.hidden = true; var d = $("#bookDone"); d.hidden = false; renderMsg(); d.focus();
        setText("#bookRef", (ar ? "رقم الطلب: " : "Your reference: ") + bookRef);
        if (window.gtag) window.gtag("event", "booking_request", { package: val("#bPkg") });
      }
      function fail() {
        btn.disabled = false;
        state.textContent = ar ? "تعذّر إرسال البريد. أرسلوا طلبكم عبر واتساب أو اتصلوا بنا." : "The email could not be sent. Please send your request on WhatsApp or call us.";
        var sb = $("#bSend"); if (sb && hasWa()) { sb.hidden = false; sb.href = waUrl(buildMsg()); }

      }
      if (!to) { fail(); return; }
      btn.disabled = true; state.textContent = ar ? "جارٍ الإرسال…" : "Sending…";
      fetch("https://formsubmit.co/ajax/" + String(to).trim(), {
        method: "POST", headers: { "Content-Type": "application/json", "Accept": "application/json" }, body: JSON.stringify(data)
      }).then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { if (r.ok && String(j.success) !== "false") done(); else fail(); }); }, fail);
    });
  }

  /* ---------- book page: package from hash ---------- */
  (function () {
    var sel = $("#bPkg"), h = (location.hash || "").slice(1);
    if (sel && ["pathway", "apply", "arrive", "private"].indexOf(h) > -1) sel.value = h;
  })();

  /* ---------- analytics (only when an ID is set) ---------- */
  (function () {
    var id = S.analytics && S.analytics.ga4; if (!id) return;
    var s = document.createElement("script"); s.async = true; s.src = "https://www.googletagmanager.com/gtag/js?id=" + encodeURIComponent(id); document.head.appendChild(s);
    window.dataLayer = window.dataLayer || []; window.gtag = function () { window.dataLayer.push(arguments); };
    window.gtag("js", new Date()); window.gtag("config", id);
    document.addEventListener("click", function (e) {
      var a = e.target.closest("a,button"); if (!a) return;
      if (a.id === "bSend" || /wa\.me/.test(a.href || "")) window.gtag("event", "whatsapp_click");
      if ((a.href || "").indexOf("tel:") === 0) window.gtag("event", "phone_click");
      if (/book\.html/.test(a.getAttribute("href") || "")) window.gtag("event", "book_click");
    });
  })();

  /* ---------- start ---------- */
  var yr = $("#yr"); if (yr) yr.textContent = String(new Date().getFullYear());
  var saved = store("se-lang");
  var pageLang = root.getAttribute("data-page-lang");
  setLang(pageLang || (saved === "ar" || saved === "en" ? saved : ((navigator.language || "").toLowerCase().indexOf("ar") === 0 ? "ar" : "en")));
  setupWelcome();
  startRotate();
  route();
})();
